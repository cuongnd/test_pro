<?php

defined('_JEXEC') or die('Restricted access');

if (!class_exists('vmPSPlugin'))
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');

class plgVmShipmentPro_ship extends vmPSPlugin {

    // instance of class
    public static $_this = false;

    function __construct(& $subject, $config) {
	parent::__construct($subject, $config);

	$this->_loggable = true;
	$this->tableFields = array_keys($this->getTableSQLFields());
	$varsToPush = $this->getVarsToPush();
	$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
    }

    /**
     * Create the table for this plugin if it does not yet exist.
     * @author Valérie Isaksen
     */
    public function getVmPluginCreateTableSQL() {

	return $this->createTableSQL('Pro Ship Table');
    }

    function getTableSQLFields() {
	$SQLfields = array(
	    'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
	    'virtuemart_order_id' => 'int(11) UNSIGNED',
	    'order_number' => 'char(32)',
	    'virtuemart_shipmentmethod_id' => 'mediumint(1) UNSIGNED',
	    'shipment_name' => 'varchar(5000)',
	    'order_weight' => 'decimal(10,4)',
	    'shipment_weight_unit' => 'char(3) DEFAULT \'LB\'',
	    'shipment_cost' => 'decimal(10,2)',
	    'shipment_package_fee' => 'decimal(10,2)',
	    'tax_id' => 'smallint(1)'
	);
	return $SQLfields;
    }

    /**
     * This method is fired when showing the order details in the frontend.
     * It displays the shipment-specific data.
     *
     * @param integer $order_number The order Number
     * @return mixed Null for shipments that aren't active, text (HTML) otherwise
     * @author Valérie Isaksen
     * @author Max Milbers
     */
    public function plgVmOnShowOrderFEShipment($virtuemart_order_id, $virtuemart_shipmentmethod_id, &$shipment_name) {
	$this->onShowOrderFE($virtuemart_order_id, $virtuemart_shipmentmethod_id, $shipment_name);
    }

    /**
     * This event is fired after the order has been stored; it gets the shipment method-
     * specific data.
     *
     * @param int $order_id The order_id being processed
     * @param object $cart  the cart
     * @param array $priceData Price information for this order
     * @return mixed Null when this method was not selected, otherwise true
     * @author Valerie Isaksen
     */
    function plgVmConfirmedOrder(VirtueMartCart $cart, $order) {
	if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_shipmentmethod_id))) {
	    return null; // Another method was selected, do nothing
	}
	if (!$this->selectedThisElement($method->shipment_element)) {
	    return false;
	}
	$values['virtuemart_order_id'] = $order['details']['BT']->virtuemart_order_id;
	$values['order_number'] = $order['details']['BT']->order_number;
	$values['virtuemart_shipmentmethod_id'] = $order['details']['BT']->virtuemart_shipmentmethod_id;
	$values['shipment_name'] = $this->renderPluginName($method);
	$values['order_weight'] = $this->getOrderWeight($cart, $method->weight_unit);
	$values['shipment_weight_unit'] = $method->weight_unit;
	$values['shipment_cost'] = $method->cost;
	$values['shipment_package_fee'] = $method->package_fee;
	$values['tax_id'] = $method->tax_id;
	$this->storePSPluginInternalData($values);

	return true;
    }
 



     function getCosts(VirtueMartCart $cart, $method, $cart_prices) {
	$orderWeight = $this->getOrderWeight($cart, $method->weight_unit);
	$nbproducts = $this->_nbproductsCond($cart, $method);
	if ($orderWeight <=0){
	return 0;}
	elseif ($nbproducts >=$method->nbproducts_quantity && $orderWeight >=1 && $method->nbproducts_1fee ==0 ){return $method->nbproducts_fee * $nbproducts;}
		elseif ($nbproducts >=$method->nbproducts_quantity && $orderWeight >=1 && $method->nbproducts_1fee >0 ){
		$nbproducts=$nbproducts-1;
		$temp=$nbproducts *$method->nbproducts_fee;
		return $temp+$method->nbproducts_1fee;
		}
			elseif ($nbproducts >=$method->nbproducts_quantity2 && $orderWeight >=1 && $method->nbproducts_1fee2 ==0 ){return $method->nbproducts_fee2 * $nbproducts;}
		elseif ($nbproducts >=$method->nbproducts_quantity2 && $orderWeight >=1 && $method->nbproducts_1fee2 >0 ){
		$nbproducts=$nbproducts-1;
		$temp=$nbproducts *$method->nbproducts_fee2;
		return $temp+$method->nbproducts_1fee2;
		}
  elseif ($method->free_shipment && $cart_prices['salesPrice'] >= $method->free_shipment) {
	    return 0;}
	elseif ($orderWeight >= $method->weight_min1 && $orderWeight <=$method->weight_max1){
	return $orderWeight * $method->rate1;
}
	elseif ($orderWeight >= $method->weight_min2 && $orderWeight <=$method->weight_max2){
	return $orderWeight * $method->rate2;
}
	elseif ($orderWeight >= $method->weight_min3 && $orderWeight <=$method->weight_max3){
	return $orderWeight * $method->rate3;
}
	elseif ($orderWeight >= $method->weight_min4 && $orderWeight <=$method->weight_max4){
	return $orderWeight * $method->rate4;
}
elseif ($orderWeight >= $method->weight_min5 && $orderWeight <=$method->weight_max5){
	return $orderWeight * $method->rate5;
}
elseif ($orderWeight >= $method->weight_min6 && $orderWeight <=$method->weight_max6){
	return $method->rate6 * $orderWeight;
}
	else{
	    return $method->elsecost;
	}
	
    }

    protected function checkConditions($cart, $method, $cart_prices) {
	$this->convert($method);
  $orderWeight = 0;
	$orderWeight = $this->getOrderWeight($cart, $method->weight_unit);
	$address = (($cart->ST == 0) ? $cart->BT : $cart->ST);

	$nbShipment = 0;
	$countries = array();
	if (!empty($method->countries)) {
	    if (!is_array($method->countries)) {
		$countries[0] = $method->countries;
	    } else {
		$countries = $method->countries;
	    }
	}
	// probably did not gave his BT:ST address
	if (!is_array($address)) {
	    $address = array();
	    $address['zip'] = 0;
	    $address['virtuemart_country_id'] = 0;
	}
	$weight_cond = $this->_weightCond($orderWeight, $method);
	$nbproducts_cond = $this->_nbproductsCond($cart, $method);
	$orderamount_cond = $this->_orderamountCond($cart_prices, $method);
	if (isset($address['zip'])) {
	    $zip_cond = $this->_zipCond($address['zip'], $method);
	} else {
	    //no zip in address data normally occurs only, when it is removed from the form by the shopowner
	    //Todo for  valerie, you may take a look, maybe should be false, or configurable.
	    $zip_cond = true;
	}

	if (!isset($address['virtuemart_country_id']))
	    $address['virtuemart_country_id'] = 0;
	if (in_array($address['virtuemart_country_id'], $countries) || count($countries) == 0) {
	    if ($weight_cond AND $zip_cond AND $nbproducts_cond AND $orderamount_cond) {
		return true;
	    }
	}

	return false;
    }

    function convert(&$method) {
	$method->weight_start = (float) $method->weight_start;
	$method->weight_stop = (float) $method->weight_stop;
	$method->orderamount_start = (float) $method->orderamount_start;
	$method->orderamount_stop = (float) $method->orderamount_stop;
	$method->zip_start = (int) $method->zip_start;
	$method->zip_stop = (int) $method->zip_stop;
	$method->nbproducts_start = (int) $method->nbproducts_start;
	$method->nbproducts_stop = (int) $method->nbproducts_stop;
    }

    private function _weightCond($orderWeight, $method) {
	if ($orderWeight) {

	    $weight_cond = ($orderWeight >= $method->weight_start AND $orderWeight <= $method->weight_stop
		    OR
		    ($method->weight_start <= $orderWeight AND ($method->weight_stop == 0) ));
	} else
	    $weight_cond = true;
	return $weight_cond;
    }

    private function _nbproductsCond($cart, $method) {
	$nbproducts = 0;
	foreach ($cart->products as $product) {
	    $nbproducts += $product->quantity;
	}
	return $nbproducts;
    }
    
    // working on this product ID method working
    private function _ids($cart, $method) {
	foreach ($cart->products as $product) {
	    if ($product->virtuemart_product_id ==98){$result=50;}
	}
	return $result;
    }

    private function _orderamountCond($cart_prices, $method) {
	$orderamount = 0;

	if (!isset($method->orderamount_start) AND !isset($method->orderamount_stop)) {
	    return true;
	}
	if ($cart_prices['salesPrice']) {
	    $orderamount_cond = ($cart_prices['salesPrice'] >= $method->orderamount_start AND $cart_prices['salesPrice'] <= $method->orderamount_stop
		    OR
		    ($method->orderamount_start <= $cart_prices['salesPrice'] AND ($method->orderamount_stop == 0) ));
	} else {
	    $orderamount_cond = true;
	}
	return $orderamount_cond;
    }

    /**
     * Check the conditions on Zip code
     * @param int $zip : zip code
     * @param $params paremters for this specific shiper
     * @author Valérie Isaksen
     * @return string if Zip condition is ok or not
     */
    private function _zipCond($zip, $method) {
	$zip=(int)$zip;
	if (!empty($zip)) {
	    $zip_cond = (( $zip >=   $method->zip_start AND $zip <=   $method->zip_stop )
		    OR
		    (  $method->zip_start <= $zip AND (  $method->zip_stop == 0) ));
	} else {
	    $zip_cond = true;
	}
	return $zip_cond;
    }

    function plgVmOnStoreInstallShipmentPluginTable($jplugin_id) {
	return $this->onStoreInstallPluginTable($jplugin_id);
    }


    public function plgVmOnSelectCheckShipment(VirtueMartCart &$cart) {
	return $this->OnSelectCheck($cart);
    }

    public function plgVmDisplayListFEShipment(VirtueMartCart $cart, $selected = 0, &$htmlIn) {
	return $this->displayListFE($cart, $selected, $htmlIn);
    }



    public function plgVmonSelectedCalculatePriceShipment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {
	return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }


    function plgVmOnCheckAutomaticSelectedShipment(VirtueMartCart $cart, array $cart_prices = array()) {
	return $this->onCheckAutomaticSelected($cart, $cart_prices);
    }


    function plgVmonShowOrderPrint($order_number, $method_id) {
	return $this->onShowOrderPrint($order_number, $method_id);
    }


    function plgVmDeclarePluginParamsShipment($name, $id, &$data) {

	return $this->declarePluginParams('shipment', $name, $id, $data);
    }

    function plgVmSetOnTablePluginParamsShipment($name, $id, &$table) {
	return $this->setOnTablePluginParams($name, $id, $table);
    }

}

// No closing tag
